export class AppSettings {
    public accountManagementWebApiUrl: string;
    public inventoryManagementWebApiUrl: string;
    public purchaseOrderManagementWebApiUrl: string;
    public salesOrderManagementWebApiUrl: string;
}
